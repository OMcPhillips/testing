package dsaii.collections;

public class StackEmptyException extends RuntimeException {
}
