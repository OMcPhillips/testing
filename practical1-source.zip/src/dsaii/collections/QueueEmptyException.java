package dsaii.collections;

public class QueueEmptyException extends RuntimeException{
}
