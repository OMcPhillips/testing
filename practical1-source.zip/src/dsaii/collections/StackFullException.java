package dsaii.collections;

public class StackFullException extends RuntimeException {
}
